#!/usr/bin/env python3
"""
AI Compliance Evidence Collector — Prototype Matching Engine
Capstone: MBA ZG583 - Management of AI Products
Student: Bhandare Kiran Arun Madhuri (2024BC26620)

Demonstrates the core control-to-evidence matching / gap-flagging workflow
described in the PRD and AI Intelligence Layer documents, using a transparent
lexical-overlap scorer so the demo runs offline with no API keys.

Production design note: this scoring function is a stand-in for the two-stage
"embedding retrieval + LLM judgment" pipeline described in
05-AI_Intelligence_Layer.docx. The interfaces (confidence band, rationale,
gap routing) are the same, so swapping in a real embedding/LLM call later is
a drop-in change, not a redesign.
"""

import json
import re
import sys
from pathlib import Path

STOPWORDS = {
    "a", "an", "the", "and", "or", "of", "to", "in", "for", "on", "with",
    "shall", "be", "is", "are", "that", "this", "including", "such", "as",
    "by", "at", "all", "each", "will", "if", "required", "process",
}

CONFIDENCE_MATCHED = 0.45
CONFIDENCE_REVIEW = 0.15


def stem(word: str) -> str:
    """Very lightweight suffix stripping so 'backups'/'backup' and
    'tested'/'testing' overlap. Not a real stemmer — good enough for a
    transparent demo, and a concrete illustration of why the production
    design (Section 05) uses embeddings/LLM judgment rather than raw
    lexical matching for the real product."""
    for suffix in ("ing", "ies", "ed", "es", "s"):
        if word.endswith(suffix) and len(word) - len(suffix) > 3:
            return word[: -len(suffix)]
    return word


def tokenize(text: str) -> set:
    words = re.findall(r"[a-zA-Z]+", text.lower())
    return {stem(w) for w in words if w not in STOPWORDS and len(w) > 2}


def score(control_text: str, evidence_text: str) -> float:
    """Overlap coefficient: intersection size / size of the smaller set.
    More robust than Jaccard when comparing a short control description
    against a longer evidence excerpt of very different length."""
    c_tokens = tokenize(control_text)
    e_tokens = tokenize(evidence_text)
    if not c_tokens or not e_tokens:
        return 0.0
    overlap = c_tokens & e_tokens
    smaller = min(len(c_tokens), len(e_tokens))
    return len(overlap) / smaller


def band(conf: float) -> str:
    if conf >= CONFIDENCE_MATCHED:
        return "MATCHED"
    if conf >= CONFIDENCE_REVIEW:
        return "NEEDS REVIEW"
    return "GAP"


def rationale(control, evidence, conf, shared_terms) -> str:
    if evidence is None:
        return "No candidate evidence scored high enough to suggest a match."
    terms = ", ".join(sorted(shared_terms)) if shared_terms else "no significant shared terms"
    return (
        f"Best candidate '{evidence['evidence_id']}' from {evidence['source_system']} "
        f"(confidence {conf:.2f}) — overlapping concepts: {terms}."
    )


def match_controls(controls, evidence_list):
    results = []
    for control in controls:
        control_text = f"{control['title']} {control['description']}"
        scored = []
        for ev in evidence_list:
            s = score(control_text, ev["content"])
            shared = tokenize(control_text) & tokenize(ev["content"])
            scored.append((s, ev, shared))
        scored.sort(key=lambda x: x[0], reverse=True)
        best_score, best_ev, best_shared = scored[0] if scored else (0.0, None, set())
        status = band(best_score)
        results.append({
            "control_id": control["control_id"],
            "title": control["title"],
            "status": status,
            "confidence": round(best_score, 2),
            "matched_evidence": best_ev["evidence_id"] if (best_ev and status != "GAP") else None,
            "rationale": rationale(control, best_ev if status != "GAP" else None, best_score, best_shared),
        })
    return results


def main():
    base = Path(__file__).parent
    controls = json.loads((base / "sample_controls.json").read_text())
    evidence = json.loads((base / "sample_evidence.json").read_text())

    results = match_controls(controls, evidence)

    print("=" * 78)
    print("AI COMPLIANCE EVIDENCE COLLECTOR — MATCH REPORT")
    print("=" * 78)
    counts = {"MATCHED": 0, "NEEDS REVIEW": 0, "GAP": 0}
    for r in results:
        counts[r["status"]] += 1
        print(f"\n[{r['status']}] {r['control_id']} — {r['title']}")
        print(f"  Confidence: {r['confidence']}")
        print(f"  Rationale : {r['rationale']}")

    print("\n" + "-" * 78)
    print(f"Summary: {counts['MATCHED']} Matched | "
          f"{counts['NEEDS REVIEW']} Needs Review | "
          f"{counts['GAP']} Gap")
    print("-" * 78)
    print("\nReminder: every MATCHED / NEEDS REVIEW result still requires a human")
    print("reviewer's accept/reject before it is used in an actual audit submission.")


if __name__ == "__main__":
    sys.exit(main())
